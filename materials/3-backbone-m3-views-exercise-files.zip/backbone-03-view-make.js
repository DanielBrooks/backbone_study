var el = new Backbone.View().make(
    'h3',
    {class: 'not-very-important'},
    'Preliminary Version'
);

// <h3 class="not-very-important">Preliminary Version</h3>
console.log(el);
​