var ford = new Backbone.Model({});

console.log(ford.id);

console.log(ford.cid);

console.log(ford.isNew());