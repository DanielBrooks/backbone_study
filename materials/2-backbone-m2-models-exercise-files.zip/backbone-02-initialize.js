var Vehicle = Backbone.Model.extend({

	initialize: function () {
		console.log('vehicle created');
	}
	
});
