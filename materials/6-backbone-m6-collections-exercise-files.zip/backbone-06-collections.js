var c = new Backbone.Collection([
    {name: 'thing'},
    {name: 'other'}
]);

console.log(c.length);

console.log(c.at(0));